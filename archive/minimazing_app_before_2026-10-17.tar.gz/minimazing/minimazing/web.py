"""Local web app over one opened Backup: a JSON API (this file) plus the
static frontend in minimazing/static/. Binds to 127.0.0.1 by default so
nothing leaves the machine. Stdlib only - no Flask/etc. dependency.
"""
from __future__ import annotations

import csv
import io
import json
import mimetypes
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .extractors import READERS, CATALOG, available

STATIC_DIR = Path(__file__).parent / "static"


def _json_bytes(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


def _csv_bytes(records: list[dict]) -> bytes:
    if not records:
        return b""
    cols = list({k: None for r in records for k in r})
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    for r in records:
        w.writerow({k: (v if not isinstance(v, (list, dict)) else json.dumps(v))
                    for k, v in r.items()})
    return buf.getvalue().encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    backup = None  # set by serve()
    _cache: dict = {}  # dataset key -> records, populated lazily per backup

    def log_message(self, *a):  # quiet access log
        pass

    # ---------- helpers ----------
    def _send_bytes(self, data: bytes, code=200, ctype="application/octet-stream",
                     extra_headers: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in (extra_headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, obj, code=200):
        self._send_bytes(_json_bytes(obj), code, "application/json; charset=utf-8")

    def _records(self, key: str) -> list[dict]:
        if key not in self._cache:
            self._cache[key] = READERS[key](self.backup)
        return self._cache[key]

    def _static(self, rel_path: str):
        path = (STATIC_DIR / rel_path).resolve()
        if STATIC_DIR not in path.parents and path != STATIC_DIR:
            return self._send_json({"error": "not found"}, 404)
        if not path.is_file():
            return self._send_json({"error": "not found"}, 404)
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        self._send_bytes(path.read_bytes(), 200, ctype)

    # ---------- routing ----------
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        parts = [p for p in parsed.path.split("/") if p]
        qs = urllib.parse.parse_qs(parsed.query)
        try:
            if not parts:
                return self._static("index.html")
            if parts[0] == "api":
                return self._api(parts[1:], qs)
            return self._static("/".join(parts))
        except Exception as e:  # never let a stack trace leak to the browser
            self._send_json({"error": str(e)}, 500)

    def _api(self, parts, qs):
        b = self.backup
        if parts == ["summary"]:
            s = b.summary()
            s["storage"] = b.storage_breakdown()
            return self._send_json(s)

        if parts == ["datasets"]:
            out = []
            for d in CATALOG:
                entry = dict(d)
                if d["implemented"]:
                    entry["available"] = available(b, d["key"])
                    entry["count"] = len(self._records(d["key"])) if entry["available"] else 0
                else:
                    entry["available"] = False
                    entry["count"] = 0
                out.append(entry)
            return self._send_json(out)

        if len(parts) == 2 and parts[0] == "dataset":
            key = parts[1]
            if key not in READERS:
                return self._send_json({"error": f"unknown dataset {key}"}, 404)
            records = self._records(key)
            limit = 5000
            return self._send_json({
                "key": key, "total": len(records),
                "truncated": len(records) > limit,
                "records": records[:limit],
            })

        if len(parts) == 2 and parts[0] == "export":
            key = parts[1].rsplit(".", 1)[0]
            fmt = parts[1].rsplit(".", 1)[-1] if "." in parts[1] else "json"
            if key not in READERS:
                return self._send_json({"error": f"unknown dataset {key}"}, 404)
            records = self._records(key)
            if fmt == "csv":
                data, ctype = _csv_bytes(records), "text/csv"
            else:
                data, ctype = _json_bytes(records), "application/json"
            headers = {"Content-Disposition": f'attachment; filename="{key}.{fmt}"'}
            return self._send_bytes(data, 200, ctype, headers)

        if len(parts) == 2 and parts[0] == "file":
            file_id = parts[1]
            f = b.get(file_id)
            if not f:
                return self._send_json({"error": "no such file"}, 404)
            data = b.read(f)
            ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
            headers = {}
            if qs.get("download"):
                headers["Content-Disposition"] = f'attachment; filename="{f.name}"'
            return self._send_bytes(data, 200, ctype, headers)

        return self._send_json({"error": "not found"}, 404)


def serve(backup, host="127.0.0.1", port=8777, open_browser=True):
    Handler.backup = backup
    Handler._cache = {}
    srv = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}"
    print(f"minimazing running at {url}  (Ctrl-C to stop)")
    if open_browser:
        import threading
        import webbrowser
        threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        backup.close()
