"""Dataset readers.

Each reader opens one Apple app database from inside a Backup and returns
plain Python records. Domain/path naming has drifted across iOS versions
(container IDs especially), so each dataset lists candidate (domain, path)
pairs in newest-first order and uses whichever one is actually present in
*this* backup - real backups are what this gets tested against, not just
the synthetic one, so being permissive here matters more than being terse.
"""
from __future__ import annotations

import datetime as dt

from .backup import Backup

APPLE_EPOCH = dt.datetime(2001, 1, 1, tzinfo=dt.timezone.utc)

# dataset key -> ordered list of (domain, relativePath) candidates
SOURCES = {
    "messages": [("HomeDomain", "Library/SMS/sms.db")],
    "calls": [
        ("HomeDomain", "Library/CallHistoryDB/CallHistory.storedata"),
        ("HomeDomain", "Library/CallHistory/call_history.db"),
    ],
    "contacts": [("HomeDomain", "Library/AddressBook/AddressBook.sqlitedb")],
    "calendar": [("HomeDomain", "Library/Calendar/Calendar.sqlitedb")],
    "notes": [
        ("AppDomainGroup-group.com.apple.notes", "NoteStore.sqlite"),
        ("HomeDomain", "Library/Notes/notes.sqlite"),
    ],
    "safari": [
        ("AppDomainGroup-group.com.apple.mobilesafari", "Library/Safari/History.db"),
        ("AppDomainGroup-group.com.apple.safari", "Library/Safari/History.db"),
        ("HomeDomain", "Library/Safari/History.db"),
    ],
    "whatsapp": [
        ("AppDomainGroup-group.net.whatsapp.WhatsApp.shared", "ChatStorage.sqlite"),
    ],
    "photos": [("CameraRollDomain", "Media/PhotoData/Photos.sqlite")],
}

# human label + nav icon key + whether it's implemented at all, for the UI's
# full sidebar (so unimplemented datasets show up greyed-out, not missing)
CATALOG = [
    {"key": "messages", "label": "Messages", "icon": "messages", "implemented": True},
    {"key": "whatsapp", "label": "WhatsApp", "icon": "whatsapp", "implemented": True},
    {"key": "contacts", "label": "Contacts", "icon": "contacts", "implemented": True},
    {"key": "calls", "label": "Call History", "icon": "calls", "implemented": True},
    {"key": "calendar", "label": "Calendar", "icon": "calendar", "implemented": True},
    {"key": "notes", "label": "Notes", "icon": "notes", "implemented": True},
    {"key": "safari", "label": "Safari", "icon": "safari", "implemented": True},
    {"key": "photos", "label": "Photos", "icon": "photos", "implemented": True},
    {"key": "voicememos", "label": "Voice Memos", "icon": "voicememos", "implemented": False},
    {"key": "music", "label": "Music", "icon": "music", "implemented": False},
    {"key": "apps", "label": "Apps", "icon": "apps", "implemented": False},
    {"key": "files", "label": "Files", "icon": "files", "implemented": False},
]


def _t(v):
    if not v:
        return None
    v = float(v)
    if v > 1e12:  # iOS 11+ switched CalendarItem/etc. timestamps to nanoseconds in places
        v /= 1e9
    return (APPLE_EPOCH + dt.timedelta(seconds=v)).isoformat()


def _has(con, table):
    return bool(con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def _columns(con, table) -> set[str]:
    return {r["name"] for r in con.execute(f"PRAGMA table_info({table})")}


def _open(b: Backup, key: str):
    """Try each candidate path for a dataset; return the first SQLite
    connection that actually opens, or None if none of them exist here."""
    for domain, rel in SOURCES[key]:
        if b.find(domain, rel):
            con = b.sqlite(domain, rel)
            if con:
                return con
    return None


def messages(b: Backup) -> list[dict]:
    con = _open(b, "messages")
    if not con or not _has(con, "message"):
        return []
    # cache_has_attachments only exists on newer iOS versions - don't assume it.
    has_attach_col = "cache_has_attachments" in _columns(con, "message")
    attach_sql = "m.cache_has_attachments" if has_attach_col else "0"
    rows = con.execute(f"""
        SELECT m.ROWID id, c.chat_identifier chat, h.id contact,
               m.is_from_me from_me, m.date, m.text,
               {attach_sql} has_attach
        FROM message m
        LEFT JOIN handle h ON h.ROWID = m.handle_id
        LEFT JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
        LEFT JOIN chat c ON c.ROWID = cmj.chat_id
        ORDER BY m.date
    """).fetchall()
    return [{"id": r["id"], "chat": r["chat"] or r["contact"] or "Unknown",
             "contact": r["contact"], "from_me": bool(r["from_me"]),
             "date": _t(r["date"]), "text": r["text"],
             "has_attachment": bool(r["has_attach"])} for r in rows]


def calls(b: Backup) -> list[dict]:
    con = _open(b, "calls")
    if not con:
        return []
    if _has(con, "ZCALLRECORD"):
        rows = con.execute("""
            SELECT ZADDRESS addr, ZDATE date, ZDURATION dur, ZORIGINATED out, ZANSWERED ans
            FROM ZCALLRECORD ORDER BY ZDATE
        """).fetchall()
    elif _has(con, "call"):
        rows = con.execute(
            "SELECT address addr, date, duration dur, 0 out, 1 ans FROM call ORDER BY date"
        ).fetchall()
    else:
        return []
    out = []
    for r in rows:
        addr = r["addr"]
        if isinstance(addr, (bytes, bytearray)):
            addr = addr.decode("utf-8", "replace")
        out.append({"number": addr, "date": _t(r["date"]),
                    "duration_s": int(r["dur"] or 0),
                    "direction": "outgoing" if r["out"] else "incoming",
                    "answered": bool(r["ans"])})
    return out


def contacts(b: Backup) -> list[dict]:
    con = _open(b, "contacts")
    if not con or not _has(con, "ABPerson"):
        return []
    people = con.execute("""
        SELECT ROWID id, First first, Last last, Organization org
        FROM ABPerson ORDER BY Last, First
    """).fetchall()
    values = {}
    for r in con.execute(
            "SELECT record_id rid, value FROM ABMultiValue WHERE value IS NOT NULL"):
        values.setdefault(r["rid"], []).append(str(r["value"]))
    out = []
    for p in people:
        name = " ".join(x for x in (p["first"], p["last"]) if x) or p["org"]
        out.append({"id": p["id"], "name": name or "(no name)",
                    "organization": p["org"], "values": values.get(p["id"], [])})
    return out


def calendar(b: Backup) -> list[dict]:
    con = _open(b, "calendar")
    if not con or not _has(con, "CalendarItem"):
        return []
    rows = con.execute("""
        SELECT summary, start_date, end_date, all_day FROM CalendarItem ORDER BY start_date
    """).fetchall()
    return [{"title": r["summary"], "start": _t(r["start_date"]),
             "end": _t(r["end_date"]), "all_day": bool(r["all_day"])} for r in rows]


def notes(b: Backup) -> list[dict]:
    con = _open(b, "notes")
    if not con or not _has(con, "ZICCLOUDSYNCINGOBJECT"):
        return []
    # Notes' column names have shifted across iOS releases (ZTITLE1 vs ZTITLE,
    # ZSNIPPET vs ZSUMMARY, ZMODIFICATIONDATE1 vs ZMODIFICATIONDATE) - pick
    # whichever variant is actually present rather than assuming one.
    cols = _columns(con, "ZICCLOUDSYNCINGOBJECT")
    title_col = "ZTITLE1" if "ZTITLE1" in cols else "ZTITLE" if "ZTITLE" in cols else None
    snippet_col = "ZSNIPPET" if "ZSNIPPET" in cols else "ZSUMMARY" if "ZSUMMARY" in cols else None
    mod_col = ("ZMODIFICATIONDATE1" if "ZMODIFICATIONDATE1" in cols
               else "ZMODIFICATIONDATE" if "ZMODIFICATIONDATE" in cols else None)
    if not title_col:
        return []
    sel = f"{title_col} title, {snippet_col or 'NULL'} snippet, {mod_col or 'NULL'} mod"
    order = f"ORDER BY {mod_col} DESC" if mod_col else ""
    rows = con.execute(f"""
        SELECT {sel} FROM ZICCLOUDSYNCINGOBJECT WHERE {title_col} IS NOT NULL {order}
    """).fetchall()
    return [{"title": r["title"], "snippet": r["snippet"], "modified": _t(r["mod"])}
            for r in rows]


def safari(b: Backup) -> list[dict]:
    con = _open(b, "safari")
    if not con or not _has(con, "history_items"):
        return []
    rows = con.execute("""
        SELECT hi.url url, hv.title title, hv.visit_time vt
        FROM history_items hi JOIN history_visits hv ON hv.history_item = hi.id
        ORDER BY hv.visit_time DESC
    """).fetchall()
    return [{"title": r["title"] or r["url"], "url": r["url"], "visited": _t(r["vt"])}
            for r in rows]


def photos(b: Backup) -> list[dict]:
    """Return a manifest of camera-roll assets (metadata + backup file id)."""
    con = _open(b, "photos")
    if not con or not _has(con, "ZASSET"):
        return []
    rows = con.execute("""
        SELECT ZDIRECTORY dir, ZFILENAME name, ZDATECREATED created,
               ZFAVORITE fav, ZKIND kind
        FROM ZASSET ORDER BY ZDATECREATED DESC
    """).fetchall()
    out = []
    for r in rows:
        if not r["dir"] or not r["name"]:
            continue
        rel = f"Media/{r['dir']}/{r['name']}"
        f = b.find("CameraRollDomain", rel)
        out.append({"filename": r["name"], "path": rel,
                    "created": _t(r["created"]), "favorite": bool(r["fav"]),
                    "is_video": r["kind"] == 1, "size": f.size if f else 0,
                    "file_id": f.file_id if f else None})
    return out


def whatsapp(b: Backup) -> list[dict]:
    con = _open(b, "whatsapp")
    if not con or not _has(con, "ZWAMESSAGE"):
        return []
    rows = con.execute("""
        SELECT s.ZPARTNERNAME chat, m.ZISFROMME from_me, m.ZTEXT text, m.ZMESSAGEDATE date
        FROM ZWAMESSAGE m LEFT JOIN ZWACHATSESSION s ON s.Z_PK = m.ZCHATSESSION
        ORDER BY m.ZMESSAGEDATE
    """).fetchall()
    return [{"chat": r["chat"] or "Unknown", "from_me": bool(r["from_me"]),
             "text": r["text"], "date": _t(r["date"])} for r in rows]


READERS = {
    "messages": messages, "calls": calls, "contacts": contacts,
    "calendar": calendar, "notes": notes, "safari": safari,
    "photos": photos, "whatsapp": whatsapp,
}


def available(b: Backup, key: str) -> bool:
    """Cheap presence check (no query execution) used to grey out nav items."""
    return any(b.find(domain, rel) for domain, rel in SOURCES.get(key, []))
